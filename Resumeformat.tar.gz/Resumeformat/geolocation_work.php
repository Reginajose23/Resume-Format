
<html>
    <head>
        <title>Geo - location Finder</title>
    </head>
    <style>
        .body
        {
            border:5px;
            float:left;
            padding-top: 10px;
            padding-bottom: 10px;
            background-color: blue;
}
    </style>
    <body>
        <P>a<SPAN style="float: right">b</SPAN></P>
        <div class="col-md-12">
            <ol class="breadcrumb">

            </ol>
        </div>
        <table>

        </table>
    </body>
</html>