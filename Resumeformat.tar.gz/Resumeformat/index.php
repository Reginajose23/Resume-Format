<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
           <link href="themes/css/bootstrap.css" rel="stylesheet">
        <link href="themes/css/font-awesome.min.css" rel="stylesheet">
        <link href="themes/css/bootstrap-theme.css" rel="stylesheet">



        <script src="themes/js/jquery.js"></script>
        <link rel="stylesheet" href="themes/js/theme/jquery-ui.css">
        <script src="themes/js/ui/jquery-ui.js"></script>
        <script src="themes/js/bootstrap.min.js"></script>
        <script src="themes/validator/validator.js"></script>
        <script src="jqBootstrapValidation.js"></script>

        
    </head>
    <body>
        <?php





         if (isset($_POST['submit5']))
        {
             
             $name=$_POST['candi_name'];
        $surname=$_POST['sur_name'];
        $areaok=$_POST['area_of_knowledge'];
        $areaoi=$_POST['area_of_interest'];
        $jobtype=$_POST['job_type'];
        $experience=$_POST['expren_year']."years".$_POST['expren_month']."month";
        $salary=$_POST['salary_lakh']."lakh".$_POST['salary_thousand']."thousand";
        $industry=$_POST['industry_type'];
         $function=$_POST['function_area'];
        $designation=$_POST['designation'];
        $resumeh=$_POST['resume_heading'];
        $resumeo=$_POST['resume_object'];
        $resumes=$_POST['resume_summary'];
         $achieve=$_POST['achieve'];
        $clocation=$_POST['curr_location'];
        $plocation=$_POST['prefer_location'];
        $dob=$_POST['dob'];
        $gender=$_POST['gender'];
         $mobile=$_POST['mobile_no'];
        $mobile1=$_POST['alt_mobile_no'];
        $email=$_POST['email'];
        $city=$_POST['home_city'];
        $address=$_POST['present_address'];
         $address1=$_POST['permanent_address'];
        $pincode=$_POST['pincode'];
        $status=$_POST['status'];
        $hobby=$_POST['hobbie'];


         $connect=  mysql_connect("localhost","regina","regina");



  $selected=  mysql_select_db("regina");
$insertquery="INSERT INTO Resume_date (candi_name,sur_name,area_knowledge,area_interest,job_type,tot_expereince,
          ann_salary,indus_type,funct_area,designation,resume_title,resume_objective,resume_summary,achievement,curr_location,prefer_location,
          dob,gender,mobile_no,another_mobileno,email,home_city,presen_add,perman_add,pincode,marital_status,hobbies)
          VALUES ('$name','$surname','$areaok','$areaoi','$jobtype','$experience','$salary','$industry','$function','$designation',
          '$resumeh','$resumeo','$resumes','$achieve','$clocation','$plocation','$dob','$gender','$mobile','$mobile1','$email','$city','$address','$address1','$pincode','$status','$hobby')";
echo $insertquery;
  $query= mysql_query($inserquery);
  $query=mysql_query("select * from resume_date");



        class myExtension
        {
            public function  addContent($pdffile)
            {
                $this->setSourceFile($pdffile);
                $page=$this->ImportPage(1);
                $this->AddPage();
                $this->useTemplate($page);
                $this->createTextField($name,25,40,40);
            }
            public function createTextField($string,$x,$y,$width,$height=2)
            {
                $this->SetXY($x,$y);
                $this->setfont("Arial","",10);
                $this->Cell($width,$height,$string,0,0,"");
            }

            }
            $pdf=new myExtension();
            $pdf->addContent('origpdffile.php');
            $pdf->Output('newpdffile.pdf','I');



        }
         
  ?>
        
         <div class="container">

        <div  class="jumbotron">
            <div class="row">
                
                <div class="col-xs-2">
                    <img class="img-responsive" src="images.jpeg" alt="Chania" width="400" height="50">
                </div>
            <div class="col-xs-8 ">
                <h1 align="center" class="text-primary">Resume Creation</h1>
                <p align="center" class="text-danger">If you want to generate the resume,fill all details you can get it..</p>
             </div>
                <div class="col-xs-2">
                    <img class="img-responsive" src="images1.jpeg" alt="Chania" width="400" height="50">
                </div>
                     
        </div>
             
         
       
   

        
       
         
         

            <div class="row">
                <div class="well" style="background-color:lavenderblush;" >
        <form name="register" id="register" class="form-horizontal" method="post" action="index.php">

 <!1.---->  <div class="row col-md-6">
            <div class="form-group">
               <div class="col-md-10">
                   
                        <label for="" class=" container-fluid control-label text-primary"><dt>Candidate Name:</dt></label>
                  
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-user"></span>
                        <input type="text" class="form-control" name="candi_name">
                        </div>
                        <label for="" >Example:Raja</label>
                    </div>
                </div>

 
               <!2.----> <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="container-fluid control-label text-primary"><dt>Surname:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-user"></span>
                        <input type="text" class="form-control" name="sur_name">
                        </div>
                        <label for="">Example:S.</label>
                    </div>
                </div>

          <!3.----> <div class="form-group ">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Area of knowledge:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-folder-close"></span></span>
                        <input type="text" class="form-control" name="area_of_knowledge">
                    </div>
                        <label for="">Example:C,C++,Java</label>
                    </div>
                </div>

        <!4.---->        <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Area of Interest:</dt></label>
                </div>
                    <div class="col-md-10">
                       <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-screenshot"></span>
                        <input type="text" class="form-control" name="area_of_interest">
                       </div>
                        <label for="">Example:Java Developer</label>
                    </div>
                </div>

      <!5.---->        <div id="job" class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Job Type:</dt></label>
                </div>
                    <div class="radio col-md-10" id="jobs">
                        <div class="col-md-6" >
                        <label><input type="radio" name="job_type" id="job1"  onClick="show(this.form.job_type.value);" value="Fresher">Fresher</label>
                       
                        
                        <label><input type="radio" name="job_type" id="job1" onClick="show(this.form.job_type.value);" value="Experienced" >Experienced</label>
                    </div>
                </div>
            </div>

  <!6.---->           <div class="form-group" id="experience" style="display:none">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Total Experience:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="col-md-4">
                        <select class="form-control" name="expren_year">Years
                            <option value="">  </option>
                        
                            <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
</select>
                            </div>
                        <div class="col-md-2">
                            <label for="">years</label>
                        </div>
                    
                        <div class="col-md-4">
                        <select class="form-control" name="expren_month">
                            <option value="" >  </option>
    
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
</select>
                        </div>
                        <div class="col-md-2">
                        <label for="">Month</label>
                    </div>
                        
                </div>
                </div>


 <!7.---->  <div class="form-group" id="salary" style="display:none">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary">Annual Salary:</label>
                </div>
                    <div class="col-md-10">
                        <div class="col-md-4">
                        <select class="form-control" name="salary_lakh">
                        <option value="">  </option>
                            <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
</select>
                        </div>
                        <div class="col-md-2">
                       <label for="">Lakh</label>
                    </div>
                        <div class="col-md-4">
                        <select class="form-control" name="salary_thousand">
                        <option value="">  </option>
    <option value="1000">1000</option>
    <option value="2000">2000</option>
    <option value="3000">3000</option>
    <option value="4000">4000</option>
    <option value="5000">5000</option>
</select>
                        </div>
                        <div class="col-md-3">
                        <label for="">thousand</label>
                    </div>
                   </div>
                </div>

 <!exprendetails--><div id="exp_details" class="form-group" style="display:none">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Experience Details:</dt></label>
                </div>
                    <div class="col-md-10">
                        <textarea class="form-control" rows="5" name="experience_details"></textarea>

                    </div>
                </div>




  <!8.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Industry Type:</dt></label>
                </div>
                    <div class="col-md-10">
                        <select class="form-control" name="industry_type">
                        <option value="" >  </option>
                            <option value="IT">IT</option>
    <option value="Teaching">Teaching</option>
    <option value="Medical">Medical</option>
    <option value="Banking">Banking</option>
    <option value="Software">software</option>
    <option value="Hardware">hardware</option>
    <option value="Electrical">Electrical</option>
</select>
                    </div>
                </div>
           

 <!9.---->    <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Functional Area:</dt></label>
                </div>
                    <div class="col-md-10">
                        <select class="form-control" name="function_area">
                            <option value="">  </option>
    <option value="Application">Application</option>
    <option value="Programming">Programming</option>
    <option value="BPO/KPO">BPO/KPO</option>
    <option value="Teaching">Teaching</option>
    <option value="Banking">Banking</option>
      <option value="Nurse">Nurse</option>

</select>
                    </div>
                </div>

 <!10.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Designation:</dt></label>
                </div>
                    <div class="col-md-10">
                        <select class="form-control" name="designation">
                            <option value=""> </option>
    <option value="Developer">Developer</option>
    <option value="Programmer">Programmer</option>
    <option value="Teacher">Teacher</option>
    <option value="Banker">Banker</option>
    <option value="Staffnurse">Staffnurse</option>
</select>
                    </div>
                </div>

 <!11.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Resume Heading:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-header"></span>
                         <input type="text" class="form-control" name="resume_heading">
                        </div>
                         <label for="">Example:Java Developer</label>
                    </div>
                </div>

  <!12.a.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Resume Objective:</dt></label>
                </div>
      <div class="col-md-10">
                    
                <textarea class="form-control" rows="3" name="resume_object" id="comment"></textarea>
                    </div>
                    </div>
      

 <!12.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Resume Summary:</dt></label>
                </div>
                    <div class="col-md-10">
                    
                <textarea class="form-control" rows="5" name="resume_summary" id="comment"></textarea>
                    </div>
                    </div>
              

 <!12.1---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Achievement:</dt></label>
                </div>
                    <div class="col-md-10">
                    
                <textarea class="form-control" rows="5" name="achieve" id="comment"></textarea>
                    
                    </div>
                </div>

  <!12.1---->  
               <div class="form-group col-md-10">
                        <label for="" class="control-label text-primary"><mark><dt>Education Details:</dt></mark></label>
                </div>
                    <div class="form-group">
                        <div class="col-md-10">
                        <div class="col-md-3">
                        <label for="" class="control-label text-primary"><dt>10th Standard:</dt></label>
                </div>
                    <div class="col-md-5">

                <input type="text" class="form-control" name="tenth_school">
                <label for=""><dt>Schoolname</dt></label>
                    
                    </div>
                        <div class="col-md-3">
                        <input type="text" class="form-control" name="tenth_mark">
                        <label for=""><dt>Percentage(%)</dt></label>
                </div>
                    
                </div>
                    </div>
      <div class="form-group">
          <div class="col-md-10">
                        <div class="col-md-3">
                        <label for="" class="control-label text-primary"><dt>12th Standard:</dt></label>
                </div>
                    <div class="col-md-5">

                <input type="text" class="form-control" name="twelve_school">
                <label for=""><dt>Schoolname</dt></label>

                    </div>
                        <div class="col-md-3">
                        <input type="text" class="form-control" name="twelve_mark">
                        <label for=""><dt>Percentage(%)</dt></label>
                </div>

                </div>
      </div>
      <div class="form-group">
          <div class="col-md-10">
                        <div class="col-md-3">
                        <label for="" class="control-label text-primary"><dt>Graduation:</dt></label>
                </div>
                    <div class="col-md-5">

                <input type="text" class="form-control" name="grad_college">
                <label for=""><dt>Collegename</dt></label>

                    </div>

                        <div class="col-md-3">
                        <input type="text" class="form-control" name="grad_mark">
                        <label for=""><dt>Percentage(%)</dt></label>
                </div>

                </div>
      </div>
       
     
          <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Are u a post Graduate:</dt></label>
                </div>
                    <div class="radio col-md-10">
                        <div class="col-md-6">

                        <label><input type="radio" name="grade"  onClick="check(this.form.grade.value);"value="Yes">Yes</label>

                        <label><input type="radio" name="grade" onClick="check(this.form.grade.value);" value="No">No</label>
                    </div>
                </div>
            </div>
     
      <div id="postgrade" class="form-group col-md-10" style="display:none">
                        <div class="col-md-3">
                        <label for="" class="control-label text-primary"><dt>Post Graduation:</dt></label>
                </div>
                    <div class="col-md-5">

                <input type="text" class="form-control" name="post_college">
                <label for=""><dt>Collegename</dt></label>

                    </div>
          
                        <div class="col-md-3">
                        <input type="text" class="form-control" name="post_mark">
                        <label for=""><dt>Percentage(%)</dt></label>
                </div>

                </div>
 



 </div>
 <!---Next row of column-->

            <div class="row col-md-6">
         
<!13--  >    <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Current Location:</dt></label>
                </div>
                    <div class="col-md-10">
                        <select class="form-control" name="curr_location">
                                <option value=" ">  </option>
                            <option value="Madurai">Madurai</option>
    <option value="Chennai">Chennai</option>
    <option value="Coimbatore">Coimbatore</option>
    <option value="sivagangai">sivagangai</option>
    <option value="salem">salem</option>
</select>
                    </div>
                </div>

<!14--  >    <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Preferred Location:</dt></label>
                </div>
                    <div class="col-md-10">
                        <select multiple class="form-control" name="prefer_location">
                        <option value="" disabled="disabled">Choose</option>
                            <option value="Madurai">Madurai</option>
    <option value="Chennai">Chennai</option>
    <option value="Coimbatore">Coimbatore</option>
    <option value="sivagangai">sivagangai</option>
    <option value="salem">salem</option>
</select>
                    </div>
                </div>

  
 

   <!12.1---->  
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Personal Details:</dt></label>
                </div>

       <!16.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Gender:</dt></label>
                </div>
                    <div class="radio col-md-10">
                        <div class="col-md-6">
                        <label><input type="radio" name="gender" value="Male">Male</label>

                        <label><input type="radio" name="gender" value="Female">Female</label>
                    </div>
                </div>
            </div>


  <!16.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Mobile No:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-earphone"></span>
                         <input type="text" data-minlength="6" class="form-control" name="mobile_no">
                        </div>
                        <label for="">Example:9666367895</label>
                    </div>
                </div>


   <!17.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Alternative Mobile No:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-earphone"></span>
                        <input type="text" class="form-control" name="alt_mobile_no">
                        </div>
                        <label for="">Example:9666367895</label>
                    </div>
   </div>


   <!18.---->  <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Email:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-info-sign"></span>
                         <input type="email" class="form-control" name="email">
                        </div>
                        <label for="">Example:abc@xyz.com</label>
                    </div>
                </div>


   <!19---><div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Hometown/City:</dt></label>
                </div>
                    <div class="col-md-10">
                       <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-home"></span>
                        <input type="text" class="form-control" name="home_city">
                       </div>
                        <label for="">Example:Madurai</label>
                    </div>
                </div>





   <!21---><div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Pincode:</dt></label>
                </div>
                    <div class="col-md-10">
                       <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-stats"></span>
                        <input type="text" class="form-control" name="pincode">
                       </div>
                        <label for="">Example:630565</label>
                    </div>
                </div>


   <!22---> <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Marital Status:</dt></label>
                </div>
                    <div class="radio col-md-10">
                        <div class="col-md-6">
                        <label><input type="radio" name="status"  onClick="get(this.form.status.value);" value="Single" >Single</label>


                        <label><input type="radio" name="status" onClick="get(this.form.status.value);" value="Married">Married</label>
                    </div>
                </div>
            </div>

                    <div  id="father" class="form-group">
                        <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Father Name:</dt></label>
                </div>
                    <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-tree-deciduous"></span>
                <input type="text" class="form-control" name="father_name">
                    </div>

                    </div>
                    </div>

   <div  class="form-group">
       <div id="husband" style="display:none">
                        <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Spouse Name:</dt></label>
                </div>
                    <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-tower"></span>
                <input type="text" class="form-control" name="husband_name">
                    </div>

                    </div>
                    </div>
   </div>
       <!20---><div class="form-group ">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Present Address:</dt></label>
                </div>
                    <div class="col-md-10">
                        <textarea class="form-control" rows="5" name="present_address"></textarea>

                    </div>
                </div>


   <!20---><div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Permanent Address:</dt></label>
                </div>
                    <div class="col-md-10">
                        <textarea class="form-control" rows="5" name="permanent_address"></textarea>

                    </div>
                </div>
    <!15-->    <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Date of Birth:</dt></label>
                </div>
                    <div class="col-md-10">
                        <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-calendar"></span>
                        <input type="text" class="form-control" name="dob" ID="date2">
                        </div>




                         </div>

   </div>

              


   <!20 a.---><div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Technical Details:</dt></label>
                </div>
                    <div class="col-md-10">
                        <textarea class="form-control" rows="5" name="tech_details"></textarea>

                    </div>
                </div>


   <!23---> <div class="form-group">
               <div class="col-md-10">
                        <label for="" class="control-label text-primary"><dt>Hobbies:</dt></label>
                </div>
                     <div class="col-md-10">



                <textarea class="form-control" rows="5" name="hobbie" id="comment"></textarea>
                    </div>
            </div>


    </div>

             <div class="row">
       <div class="form-group">
        <div class="col-xs-offset-5 col-md-7">
            <button type="submit" name="submit5" class="once-only btn btn-primary btn-lg">Submit</button>
        </div>
    </div>
        </div>
    
 </form>
            </div>
            </div>
        </div>
        </div>
      
         
    </body>
</html>
<script>

              $(document).ready(function(){
                  $(".once-only").click(function(){
        this.disabled = true;
        return true;
    });

                  $("#date2").datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        yearRange: "-100:+0"
    });
                 

    //New loan request form validation
    $('#register').bootstrapValidator({


           message: 'This value is not valid',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },

     excluded: ':disabled',
        fields: {
             candi_name: {
                validators: {
                    notEmpty: {
                        message: 'Name is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },
            sur_name: {
                validators: {
                    notEmpty: {
                        message: 'surname is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },
            area_of_knowledge: {
                validators: {
                    notEmpty: {
                        message: 'Member Type is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },
            area_of_interest: {
                validators: {
                    notEmpty: {
                        message: 'Member Type is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },
            dob: {
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    },
                    date: {
                        format: 'DD-MM-YYYY',
                        message: 'The date is not a valid'
                    }
                }
            },

            mobile_no: {
                    validators: {
                        notEmpty: {
                        message: 'The mobile no is required'
                    },
                    digits: {
			message: 'Enter Number Only'
                         }

                       
                    }
                },

                alt_mobile_no: {
                    validators: {
                        notEmpty: {
                        message: 'The mobile no is required'
                    },
                    digits: {
			message: 'Enter Number Only'
                         },

                        stringLength: {
                            min:10,
                           
                            message: 'The mobile no should be 10 field'
                        }
                    }
                },

                email: {
                validators: {
                    notEmpty: {
                        message: 'The email-Id is required'
                    },
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            },
             home_city: {
                validators: {
                    notEmpty: {
                        message: 'City is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },
             present_address: {
                validators: {
                    notEmpty: {
                        message: 'The present address is required'
                    }
                }
            },
            
       
         permanent_address: {
                validators: {
                    notEmpty: {
                        message: 'The permanent address is required'
                    }
                }
            },
            resume_heading: {
                validators: {
                    notEmpty: {
                        message: 'The Resume object is required'
                    },
                    StringLength:
                        {
                        min:100,
                        message:' Maximum characters not allowed'
                        }

                }
            },
            resume_object: {
                validators: {
                    notEmpty: {
                        message: 'The Resume object is required'
                    }
                }
            },
             resume_summary: {
                validators: {
                    notEmpty: {
                        message: 'The Resume Summary is required'
                    }
                }
            },
           tech_details: {
                validators: {
                    notEmpty: {
                        message: 'The Technical detail is required'
                    }
                }
            },
             husband_name: {
                validators: {
                    notEmpty: {
                        message: 'Husband Name is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },

            father_name: {
                validators: {
                    notEmpty: {
                        message: 'City is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			}
                }
            },
             post_college: {
                validators: {
                    notEmpty: {
                        message: 'College Name is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			},
                        stringLength: {
                            min: 100,
                            message: 'not more than 24 character'
                        }
                }
            },
             post_mark: {
                validators: {
                    notEmpty: {
                        message: 'Overall percentage is required and cannot be empty'
                    },
                    digits: {
			message: 'Enter Number Only'
                         }

                }
            },
            grad_college: {
                validators: {
                    notEmpty: {
                        message: 'College Name is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			},
                        stringLength: {
                            max: 24,
                            message: 'not more than 24 character'
                        }
                }
            },
             grad_mark: {
                validators: {
                    notEmpty: {
                        message: 'Overall percentage is required and cannot be empty'
                    },
                    digits: {
			message: 'Enter Number Only'
                         }

                }
            },
            twelve_school: {
                validators: {
                    notEmpty: {
                        message: 'College Name is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			},
                        stringLength: {
                            max: 24,
                            message: 'not more than 24 character'
                        }
                }
            },
             twelve_mark: {
                validators: {
                    notEmpty: {
                        message: 'Overall percentage is required and cannot be empty'
                    },
                    digits: {
			message: 'Enter Number Only'
                         }

                }
            },
            tenth_school: {
                validators: {
                    notEmpty: {
                        message: 'College Name is required and cannot be empty'
                    },
                    regexp:
			{
			  regexp:/^[a-zA-Z\s]+$/,///^[A-Za-z]+$/, for characters only
			  message: 'Enter Characters Only'
			},
                        stringLength: {
                            max: 24,
                            message: 'not more than 24 character'
                        }
                }
            },
             tenth_mark: {
                validators: {
                    notEmpty: {
                        message: 'Overall percentage is required and cannot be empty'
                    },
                    digits: {
			message: 'Enter Number Only'
                         }

                }
            },

            pincode: {
                    validators: {
                        notEmpty: {
                        message: 'Pincode is required and cannot be empty'
                    },
                    digits: {

                        
			message: 'Enter Number Only'
                        
                        
                    },
                       stringLength: {
                            max: 6,
                            message: 'The pincode should be 6 field'
                        }
                    }

               },



               

                 hobbie: {
                validators: {
                    notEmpty: {
                        message: 'The hobbie is required'
                    }
                }
            },
            experience_details: {
                validators: {
                    notEmpty: {
                        message: 'The experience detail is required'
                    }
                }
            },
 
             grade: {
                validators: {
                    notEmpty: {
                        message: 'Click any choice'
                    }
                }
            },

            
           
            job_type: {
                validators: {
                    notEmpty: {
                        message: 'select Job Type and cannot be empty'
                    }

                }
            },
            
            gender: {
                validators: {
                    notEmpty: {
                        message: 'The gender is required'
                    }
                }
            },
             status: {
                validators: {
                    notEmpty: {
                        message: 'The Marital status is required'
                    }
                }
            },
           'expren_year': {
                validators: {
                    notEmpty: {
                        message: 'Please choose experience year'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        
                    }
                }
           },

           'expren_month': {
                validators: {
                    notEmpty: {
                        message: 'Please choose experience month'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        
                    }
                }
           },
           'salary_lakh': {
                validators: {
                    notEmpty: {
                        message: 'Please choose salary'
                    },
                    choice: {
                        min: 1,
                        max: 2
                       
                    }
                }
           },
           'salary_thousand': {
                validators: {
                    notEmpty: {
                        message: 'please choose salary'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        }
                }
           },
           'industry_type': {
                validators: {
                    notEmpty: {
                        message: 'please choose industry'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        
                    }
                }
           },

           'function_area': {
                validators: {
                    notEmpty: {
                        message: 'please choose function area'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        
                    }
                }
           },

           'designation': {
                validators: {
                    notEmpty: {
                        message: 'please choose designation'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        
                    }
                }
           },

           'curr_location': {
                validators: {
                    notEmpty: {
                        message: 'please choose current location'
                    },
                    choice: {
                        min: 1,
                        max: 2
                        
                    }
                }
           },

           'prefer_location': {
                validators: {
                    notEmpty: {
                        message: 'please choose preferred location'
                    },
                    choice: {
                        min: 1,
                        max: 2
                       
                    }
                }
           }

        }

           
            


        });


 


});


</script>
<script>

    function show(a)
    {
        var getvalue;
        
        //alert(a);
        var form = document.getElementById('experience');
        var form1 = document.getElementById('salary');
        var form2 = document.getElementById('exp_details');
        if(a=='Fresher')
            {
              
                form.style.display = 'none'; // hide, but let the element keep its size
form1.style.display = 'none';
form2.style.display = 'none';

              }
            else
            if(a=='Experienced')
                {
                    //alert(2);
                    //$("#experience").show();
                    form.style.display="block";
                    form1.style.display="block";
                    form2.style.display ="block";
                   //form.style.visibility="visible";
                     //form.style\n\
         // hide, but let the element keep its size
//form1.style.visibility = 'visible';
                    
                }
                
    }

    function check(a)
    {
        var getvalue;


        var form = document.getElementById('postgrade');
        //var form1 = document.getElementById('salary');
        if(a=='Yes')
            {
                //alert(1);
                form.style.display = 'block'; // hide, but let the element keep its size
//form1.style.display = 'none';


                //document.getElementById('experience').disabled=true;
                //document.getElementById('salary').disabled=true;
            }
            else
            if(a=='No')
                {
                    //alert(2);
                    //$("#experience").show();
                    form.style.display="none";
                    //form1.style.display="block";
                   //form.style.visibility="visible";
                     //form.style\n\
         // hide, but let the element keep its size
//form1.style.visibility = 'visible';

                }

    }

    function get(a)
    {
        var getvalue;


        var form = document.getElementById('husband');
        if(a=='Single')
            {
                form.style.display="none";
                // hide, but let the element keep its size
            }
            else
            if(a=='Married')
                {
                    form.style.display = 'block';
                }
    }


    </script>